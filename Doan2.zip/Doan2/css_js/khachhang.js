function xacnhan(){
    var khachhang=new Array();
    var datakh;
    datakh=JSON.parse(localStorage.getItem('khachhang'))||[];
    var hoten=document.getElementById("ho-ten").value;
    var sdt=document.getElementById("sdt").value;
    var dia_chi=document.getElementById("dia-chi").value;
    var email=document.getElementById("email").value;
    var ghi_chu=document.getElementById("ghi-chu").value;
    var magg=document.getElementById("ma-giam-gia").value;
    if(hoten =="" || sdt =="" || email == "" || dia_chi== ""){
        alert("Không được để trống");
        return false;
    }
    else if(isNaN(sdt) || sdt.length!=10){//isNaN = không pải số
        alert("Số điện thoại không đúng!");
        return false;
    }
    else{
        var kh={hoten,sdt,dia_chi,email,ghi_chu,magg};
        // khachhang.push(kh);
        datakh.push(kh);
        console.log(datakh);
        localStorage.getItem('khachhang',JSON.stringify(datakh));
    }
    
}
var list_gh = JSON.parse(localStorage.getItem('khachhang'));
console.log(list_gh);
